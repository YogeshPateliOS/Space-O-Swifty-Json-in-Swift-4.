//
//  Constant.swift
//  task2
//
//  Created by SOTSYS027 on 25/01/18.
//  Copyright © 2018 SOTSYS027. All rights reserved.
//

import Foundation
let baseUrl = "https://itunes.apple.com/search?media=music&term="
