//
//  TableViewCell.swift
//  task2
//
//  Created by SOTSYS027 on 20/01/18.
//  Copyright © 2018 SOTSYS027. All rights reserved.
//

import UIKit
import Kingfisher
class TableViewCell: UITableViewCell {
    
    @IBOutlet weak var imageartist: UIImageView!
    @IBOutlet weak var lbltrackCensoredName: UILabel!
    @IBOutlet weak var lblartistName: UILabel!
    @IBOutlet weak var lblreleaseDate: UILabel!
    @IBOutlet weak var lbltrackPrice: UILabel!
   
    var musicData: MusicDM = MusicDM(){
        didSet{
                    let mainimg = ImageResource(downloadURL: URL(string: musicData.artworkUrl100)! , cacheKey: musicData.artworkUrl100)
                    imageartist.kf.setImage(with: mainimg)
                    lbltrackCensoredName.text = musicData.trackCensoredName
                    lblartistName.text = musicData.artistName
                    lblreleaseDate.text = musicData.releaseDate.toString()
                    lbltrackPrice.text = musicData.trackPrice
            }
    }
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
// Configure the view for the selected state
    }

}
