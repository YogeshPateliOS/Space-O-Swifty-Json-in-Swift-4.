//
//  ViewController.swift
//  task2
//
//  Created by SOTSYS027 on 17/01/18.
//  Copyright © 2018 SOTSYS027. All rights reserved.
//

import UIKit
import SwiftyJSON
import Kingfisher
struct MusicDM {
    var trackCensoredName:String = ""
    var artistName :String = ""
    var releaseDate :String = ""
    var trackPrice :String = ""
    var artworkUrl100 :String = ""
    
    init() {
    }
    
    init(json : JSON) {
        trackCensoredName = json["trackCensoredName"].stringValue
          artistName = json["artistName"].stringValue
          releaseDate = json["releaseDate"].stringValue
          trackPrice = json["trackPrice"].stringValue
          artworkUrl100 = json["artworkUrl100"].stringValue
    }
}
class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate {
    
    @IBOutlet weak var searchcontroller: UISearchBar!
    var arrdata = [MusicDM]()
    var searchActive: Bool = false
    var filtered: [MusicDM] = []
    let baseurl = "https://itunes.apple.com/search?media=music&term="
    var strSearch:String = ""
    var strBollywood:String = "bollywood"
    @IBOutlet weak var myseg: UISegmentedControl!
    @IBOutlet weak var tableview: UITableView!
  
    @IBAction func btnseg(_ sender: UISegmentedControl) {
    switch myseg.selectedSegmentIndex {
        case 0:
            searchcontroller.text = nil
            break
        case 1:
            searchcontroller.text = nil
            break
        default:
            break
        }
        self.tableview.reloadData()
}
     override func viewDidLoad() {
        super.viewDidLoad()
        getLocalData()
        getGlobalData()
        print(arrdata)
        print(filtered)
}
    //SeacrhBar Method..
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        searchActive = true
    }
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
       searchActive = false
    }
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
       searchActive = false
    }

    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
       searchActive = false
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        switch myseg.selectedSegmentIndex {
        case 0:
            if searchText == ""
            {
                searchActive = false
            }else{
                searchActive = true
            }
            filtered = arrdata.filter {
                return $0.artistName.contains(searchText)
            }
            self.tableview.reloadData()
            break
        case 1:
            if searchText == ""
            {
                searchActive = false
            }else{
                searchActive = true
            }
            strSearch = searchText
            getGlobalData()
            filtered = arrdata.filter {
                return $0.artistName.contains(searchText)
            }
            self.tableview.reloadData()
            break
        default:
            break
        }
}
    func getLocalData(){
        ApiManager.sharedInstance.getDataFromJson(url:"\(baseurl)\(strBollywood)") { (json) in
         print(json)
            let arrJson = json["results"]
            print("arrJson : ",arrJson)
            for arr in arrJson.arrayValue{
                self.arrdata.append(MusicDM(json: arr))
            }
            DispatchQueue.main.async {
                self.tableview.reloadData()
            }
    }
}
    func getGlobalData(){
        let str = "\(baseurl)\(strSearch)"
        let urlString = str.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)
        ApiManager.sharedInstance.getDataFromJson(url:urlString!) { (json) in
            print(json)
            let arrJson = json["results"]
            print("arrJson : ",arrJson)
            for arr in arrJson.arrayValue{
                self.arrdata.append(MusicDM(json: arr))
            }
            DispatchQueue.main.async {
                self.tableview.reloadData()
            }
        }
}
 //  TableView Methods implementation
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let mainvalue = 0
        switch myseg.selectedSegmentIndex {
        case 0:
            if searchActive{
                return filtered.count
            }else{
                return arrdata.count
            }
        case 1:
            if searchActive{
                return filtered.count
                
            }else{
                return arrdata.count
            }
        default:
            break
        }
        return mainvalue
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:TableViewCell = tableView.dequeueReusableCell(withIdentifier: "cell") as! TableViewCell
        switch myseg.selectedSegmentIndex {
        case 0:
            cell.musicData = arrdata[indexPath.row]
            if searchActive
            {
              cell.musicData = filtered[indexPath.row]
            }
            break
       case 1:
        if searchActive
            {
                cell.musicData = filtered[indexPath.row]
            }
            break
        default:
            break
        }
        return cell
        }
   // Dynamic Height for AutoLayout Constrain
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 90
    }
}
//Extension to Convert Date To String
//we create a string extension so we extend class string and add method toStirng()  in string class means extension string
//So with string then " . "  we can able to access tostring function that we created in extension
//in this extension the return type is string so we return a string
extension String{
    //Function with out argument but with return type string so we need to return a string
    func toString() -> String{
        let formatter = DateFormatter()//
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ssZ"//input format
        let yourDate = formatter.date(from: self)//Here we set a self date
        formatter.dateFormat = "MM/dd/yyyy"//Output Format
        return formatter.string(from: yourDate!)//Here we convert our set date format to string
    }
}

