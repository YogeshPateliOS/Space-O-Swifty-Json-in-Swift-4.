//
//  ApiManager.swift
//  task2
//
//  Created by SOTSYS027 on 25/01/18.
//  Copyright © 2018 SOTSYS027. All rights reserved.
//

import UIKit
import SwiftyJSON
class ApiManager: NSObject {
    static let sharedInstance = ApiManager()
    func getDataFromJson(url: String, completion: @escaping (_ success: JSON) -> Void){
        let request = URLRequest(url: URL(string: url)!)
        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            guard let data = data, error == nil else {
                print("error")
                return
            }
            do{
                
                let json2 = try JSON(data : data)
              print(json2)
                completion(json2)
            }catch{
                print("search json error")
            }
        }
        task.resume()
    }
}
